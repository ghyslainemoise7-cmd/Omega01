# ☆ ØMEGĀ♧01 — Starter

This is a starter web app, not a completed production platform.

## What is included
- Black and gold responsive interface
- Supabase email sign-up / sign-in
- Basic upload form for images and videos
- Uses the `videos` Storage bucket and the `videos` database table already discussed
- Capacitor configuration to prepare an Android wrapper later

## Connect Supabase
1. Copy `.env.example` to `.env`.
2. Put your Supabase Project URL in `VITE_SUPABASE_URL`.
3. Put the public Publishable key in `VITE_SUPABASE_PUBLISHABLE_KEY`.
4. Never use a Secret key or `service_role` key in browser/mobile code.
5. Restart the development server after editing `.env`.

## Important database notes
- The current upload code saves new posts with `status = 'pending'`. A moderation/admin flow must approve posts before they show in the public feed.
- Your `videos.media_url` currently stores the Storage object path, not a public URL.
- The `videos` bucket is private. To show files, implement signed URLs after verifying the user is allowed to access each post.
- Make sure Row Level Security policies are correct before public launch. Do not rely on client-side hiding for admin features or money/reward balances.
- The automatic `profiles` trigger should be fixed and tested before depending on profiles in the app.

## Build (requires a computer or cloud development environment with Node.js)
```bash
npm install
npm run dev
```

## Android
This starter includes Capacitor, but it does not contain a compiled APK.
After building the web app:
```bash
npm run build
npx cap add android
npx cap sync android
```
Building/signing the APK usually requires Android build tooling (often Android Studio or a cloud build environment).

## Not included yet
Likes and comments UI wired to Supabase, follow graph, profiles/edit profile, search, moderation/admin dashboard, notifications, rewards wallet, payouts, anti-abuse controls, reporting/blocking, and production security review.
