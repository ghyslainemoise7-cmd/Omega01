import { useEffect, useState } from 'react'
import { supabase, isSupabaseConfigured } from './supabase'
import { Home, Search, PlusSquare, UserRound, Heart, MessageCircle, LogOut, UploadCloud, PlayCircle } from 'lucide-react'

export default function App() {
  const [session, setSession] = useState(null)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [mode, setMode] = useState('signup')
  const [message, setMessage] = useState('')
  const [posts, setPosts] = useState([])
  const [title, setTitle] = useState('')
  const [file, setFile] = useState(null)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    if (!supabase) return
    supabase.auth.getSession().then(({ data }) => setSession(data.session))
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => setSession(nextSession))
    return () => listener.subscription.unsubscribe()
  }, [])

  useEffect(() => {
    if (session) loadPosts()
  }, [session])

  async function loadPosts() {
    if (!supabase) return
    const { data, error } = await supabase.from('videos').select('id,title,description,media_url,media_type,created_at,user_id').eq('status', 'published').order('created_at', { ascending: false }).limit(30)
    if (error) setMessage('Pa kapab chaje piblikasyon yo: ' + error.message)
    else setPosts(data || [])
  }

  async function authSubmit(e) {
    e.preventDefault()
    if (!supabase) return
    setBusy(true); setMessage('')
    const result = mode === 'signup'
      ? await supabase.auth.signUp({ email, password })
      : await supabase.auth.signInWithPassword({ email, password })
    setBusy(false)
    if (result.error) setMessage(result.error.message)
    else if (mode === 'signup' && !result.data.session) setMessage('Kont lan kreye. Verifye imèl ou si Supabase mande konfimasyon.')
    else setMessage('Ou konekte!')
  }

  async function uploadPost(e) {
    e.preventDefault()
    if (!supabase || !session?.user || !file) return
    setBusy(true); setMessage('')
    const userId = session.user.id
    const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_')
    const path = `${userId}/${Date.now()}-${safeName}`
    const { error: uploadError } = await supabase.storage.from('videos').upload(path, file, { upsert: false, contentType: file.type })
    if (uploadError) { setBusy(false); setMessage('Upload pa reyisi: ' + uploadError.message); return }
    // The bucket is private. Save the storage path, not a public URL.
    const { error: insertError } = await supabase.from('videos').insert({
      user_id: userId,
      title: title || file.name,
      description: '',
      media_url: path,
      media_type: file.type.startsWith('image/') ? 'image' : 'video',
      status: 'pending'
    })
    setBusy(false)
    if (insertError) setMessage('Fichye a monte men piblikasyon an pa anrejistre: ' + insertError.message)
    else { setMessage('Piblikasyon an voye pou verifikasyon. Li poko parèt nan fil piblik la.'); setTitle(''); setFile(null); e.target.reset() }
  }

  if (!isSupabaseConfigured) return <main className="setup">
    <div className="brandMark">Ω</div><p className="eyebrow">KONFIGIRASYON INISYAL</p>
    <h1>☆ ØMEGĀ♧01</h1>
    <p className="muted">Konekte pwojè a ak Supabase pou kont yo ak piblikasyon yo fonksyone.</p>
    <div className="step"><b>1.</b> Renome fichye <code>.env.example</code> la pou <code>.env</code>.</div>
    <div className="step"><b>2.</b> Mete Project URL la nan <code>VITE_SUPABASE_URL</code>.</div>
    <div className="step"><b>3.</b> Mete Publishable key la nan <code>VITE_SUPABASE_PUBLISHABLE_KEY</code>.</div>
    <p className="warning">Pa janm mete Secret key oswa service_role nan aplikasyon an.</p>
    <p className="muted small">Apre sa, rekòmanse sit la. Sa a se yon modèl demaraj; li poko pibliye sou entènèt.</p>
  </main>

  return <div className="appShell">
    <header className="topbar">
      <div className="brand"><span className="brandMark smallMark">Ω</span><span>☆ ØMEGĀ♧01</span></div>
      <span className="liveTag">BETA</span>
    </header>
    {!session ? <main className="authCard">
      <div className="heroLogo">Ω</div>
      <p className="eyebrow">KREYE. PATAJE. DEKOUVRI.</p>
      <h1>Antre nan kominote a.</h1>
      <p className="muted">Pataje foto ak videyo ou, epi dekouvri sa lòt moun ap kreye.</p>
      <form onSubmit={authSubmit} className="authForm">
        <label>Imèl<input type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="ou@egzanp.com" /></label>
        <label>Modpas<input type="password" required minLength={6} value={password} onChange={e => setPassword(e.target.value)} placeholder="Omwen 6 karaktè" /></label>
        <button className="goldButton" disabled={busy}>{busy ? 'Tanpri tann…' : mode === 'signup' ? 'Kreye kont' : 'Konekte'}</button>
      </form>
      <button className="textButton" onClick={() => { setMode(mode === 'signup' ? 'login' : 'signup'); setMessage('') }}>
        {mode === 'signup' ? 'Ou deja gen kont? Konekte' : 'Ou poko gen kont? Kreye youn'}
      </button>
      {message && <p className="notice">{message}</p>}
    </main> : <main className="content">
      <section className="welcome"><p className="eyebrow">BYENVINI SOU</p><h1>☆ ØMEGĀ♧01</h1><p className="muted">Pataje kreyativite w. Fè kominote a grandi.</p></section>
      <section className="panel">
        <h2><UploadCloud size={19}/> Pibliye foto oswa videyo</h2>
        <form onSubmit={uploadPost} className="uploadForm">
          <label>Tit piblikasyon an<input value={title} onChange={e => setTitle(e.target.value)} placeholder="Kisa w ap pataje?" /></label>
          <label className="filePicker"> <PlusSquare size={20}/> Chwazi foto oswa videyo<input type="file" accept="image/*,video/*" required onChange={e => setFile(e.target.files?.[0] || null)} /></label>
          {file && <p className="small muted">Fichye chwazi: {file.name}</p>}
          <button className="goldButton" disabled={busy || !file}>{busy ? 'Ap voye…' : 'Voye pou verifikasyon'}</button>
        </form>
        <p className="small muted">Pou sekirite, nouvo piblikasyon yo mete sou “pending” jiskaske sistèm modération an pare.</p>
      </section>
      <section className="feedHeader"><h2><PlayCircle size={20}/> Fil piblik la</h2><button className="outlineButton" onClick={loadPosts}>Rafrechi</button></section>
      {posts.length === 0 ? <div className="empty"><PlayCircle size={30}/><b>Poko gen piblikasyon piblik</b><p className="muted">Piblikasyon ki apwouve yo ap parèt la.</p></div> : <div className="feed">{posts.map(post => <article className="post" key={post.id}>
        <div className="postMedia">{post.media_type === 'image' ? <div className="mediaPlaceholder">Foto</div> : <div className="mediaPlaceholder"><PlayCircle size={38}/><span>Videyo</span></div>}</div>
        <div className="postInfo"><b>{post.title || 'Piblikasyon san tit'}</b><div className="postActions"><span><Heart size={17}/> Renmen</span><span><MessageCircle size={17}/> Kòmantè</span></div><p className="small muted">Miltimedya prive: nou bezwen siyati aksè pou montre fichye a.</p></div>
      </article>)}</div>}
      {message && <p className="notice">{message}</p>}
      <button className="logout" onClick={() => supabase.auth.signOut()}><LogOut size={17}/> Dekonekte</button>
    </main>}
    <nav className="bottomNav"><span className="active"><Home size={19}/>Akèy</span><span><Search size={19}/>Dekouvri</span><span><PlusSquare size={19}/>Kreye</span><span><UserRound size={19}/>Pwofil</span></nav>
  </div>
}
